from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
# DataBase setup
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'

db = SQLAlchemy(app)
class quiz_db(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    player_name = db.Column(db.String(200), nullable = False)
    q1 = db.Column(db.String(50), nullable = False)
    #q2 = db.Column(db.String(100), nullable = False)
    date_created = db.Column(db.DateTime, default = datetime.utcnow)

    def __repr__(self):
        return '<Task %r>' % self.id

#Main Page
@app.route('/', methods = ['GET','POST'])
def index():
    if request.method == 'POST':
        player_name = request.form.get('player_name')
        return redirect(url_for('question1', player_name = player_name))
    return render_template('index.html')

#second Page: Question 1
@app.route('/question1', methods = ['POST', 'GET'])
def question1():
    player_name = request.args.get('player_name', None)
    if request.method == 'POST':
        q1 = request.form.get('q1')
        return redirect(url_for('Summary', player_name = player_name, q1 = q1))
    return render_template('question1.html')

# Third page: Question2
# @app.route('/question2', method  = ['POST', 'GET'])
# def question2():
#     if request.method == 'POST':
#         q2 = request.form.getlist('q2')
#         return redirect(url_for('Summary', q2 = q2))
#     return render_template('question2.html')

#Forth page: Summary
@app.route('/Summary')
def Summary():
    player_name = request.args.get('player_name', None)
    q1 = request.args.get('q1', None)
    q2 = request.args.get('q2', None)
    #return redirect(url_for('question1', q1 = q1, player_name = player_name, q2 = q2 ))
    return render_template('Summary.html', q1 = q1, player_name = player_name, q2 = q2) 


# fifth page: history



if __name__ == '__main__':
    app.run(debug=True)